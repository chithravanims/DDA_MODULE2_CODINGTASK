# Task 1: Read a text document, print its contents, and handle exceptions

try:
    file_path = "sample.txt"  # change this to your file name
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
        print("File contents:\n")
        print(content)
except FileNotFoundError:
    print("Error: The specified file was not found.")
except PermissionError:
    print("Error: Permission denied while reading the file.")
except Exception as e:
    print("An unexpected error occurred:", e)
