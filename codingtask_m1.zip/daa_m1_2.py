# Task 2: Search for the word "the" and return its indices in the user-given string

user_input = input("Enter a string: ")
substring = "the"

indices = []
text = user_input.lower()
sub = substring.lower()
start = 0

while True:
    index = text.find(sub, start)
    if index == -1:
        break
    indices.append(index)
    start = index + 1  # move to next position for overlapping matches

if indices:
    print(f"Substring '{substring}' found at indices:", indices)
else:
    print(f"Substring '{substring}' not found in the text.")
