# Task 3: Read a CSV file of student data and find cells that contain 'ai'

import csv

file_path = "students.csv"  # replace with your CSV file name
substring = "ai"

try:
    with open(file_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        for row_idx, row in enumerate(reader, start=1):
            for col_idx, cell in enumerate(row, start=1):
                if substring.lower() in cell.lower():
                    print(f"'ai' found in Row {row_idx}, Column {col_idx}: {cell}")
except FileNotFoundError:
    print("Error: CSV file not found.")
except Exception as e:
    print("An unexpected error occurred:", e)
