# Task 4: Create an n*n matrix and fetch value at (i, j)

n = int(input("Enter size of matrix (n): "))

# Create matrix
matrix = []
print("Enter the elements row-wise:")
for i in range(n):
    row = list(map(int, input(f"Enter {n} numbers for row {i+1}: ").split()))
    matrix.append(row)

print("\nMatrix is:")
for row in matrix:
    print(row)

# Get i and j from user
i = int(input("\nEnter row index (1-based): "))
j = int(input("Enter column index (1-based): "))

try:
    value = matrix[i-1][j-1]
    print(f"Value at position ({i}, {j}) is: {value}")
except IndexError:
    print("Error: Index out of range. Please enter values between 1 and n.")
