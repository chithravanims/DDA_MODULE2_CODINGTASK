# Task 7: Compare sorting algorithms with empirical analysis metrics
import random, time, tracemalloc

# Bubble Sort
def bubble_sort(arr):
    comparisons = swaps = 0
    a = arr.copy()
    n = len(a)
    for i in range(n):
        for j in range(0, n - i - 1):
            comparisons += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swaps += 1
    return a, comparisons, swaps

# Insertion Sort
def insertion_sort(arr):
    comparisons = swaps = 0
    a = arr.copy()
    for i in range(1, len(a)):
        key = a[i]
        j = i - 1
        while j >= 0 and a[j] > key:
            comparisons += 1
            a[j + 1] = a[j]
            swaps += 1
            j -= 1
        a[j + 1] = key
    return a, comparisons, swaps

# Selection Sort
def selection_sort(arr):
    comparisons = swaps = 0
    a = arr.copy()
    n = len(a)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            comparisons += 1
            if a[j] < a[min_idx]:
                min_idx = j
        a[i], a[min_idx] = a[min_idx], a[i]
        swaps += 1
    return a, comparisons, swaps

# Run metrics
arr = [random.randint(0, 1000) for _ in range(100)]

def analyze_sort(sort_func, arr):
    tracemalloc.start()
    start = time.time()
    sorted_arr, comp, swaps = sort_func(arr)
    end = time.time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return {
        "time": round(end - start, 6),
        "comparisons": comp,
        "swaps": swaps,
        "memory": peak
    }

print("Empirical Analysis of Sorting Algorithms:\n")
for func in [bubble_sort, insertion_sort, selection_sort]:
    metrics = analyze_sort(func, arr)
    print(f"{func.__name__}:")
    print(f"  Time taken: {metrics['time']} sec")
    print(f"  Comparisons: {metrics['comparisons']}")
    print(f"  Swaps: {metrics['swaps']}")
    print(f"  Memory used: {metrics['memory']} bytes\n")
