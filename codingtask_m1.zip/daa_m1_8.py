# Task 8: Perform KMP and Naive search and compare comparisons and time

import time

def build_lps(pattern):
    lps = [0] * len(pattern)
    length = 0
    i = 1
    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1
    return lps

def kmp_search(text, pattern):
    lps = build_lps(pattern)
    i = j = 0
    comparisons = 0
    matches = []
    while i < len(text):
        comparisons += 1
        if text[i] == pattern[j]:
            i += 1
            j += 1
            if j == len(pattern):
                matches.append(i - j)
                j = lps[j - 1]
        else:
            if j != 0:
                j = lps[j - 1]
            else:
                i += 1
    return matches, comparisons

def naive_search(text, pattern):
    comparisons = 0
    matches = []
    for i in range(len(text) - len(pattern) + 1):
        j = 0
        while j < len(pattern):
            comparisons += 1
            if text[i + j] != pattern[j]:
                break
            j += 1
        if j == len(pattern):
            matches.append(i)
    return matches, comparisons

text = "CATSABCBCABCDOGSABCBCABC"
pattern = "ABCBCABC"

# KMP
start = time.time()
kmp_matches, kmp_comparisons = kmp_search(text, pattern)
end = time.time()
kmp_time = end - start

# Naive
start = time.time()
naive_matches, naive_comparisons = naive_search(text, pattern)
end = time.time()
naive_time = end - start

print("KMP Algorithm:")
print(f"Matches: {kmp_matches}, Comparisons: {kmp_comparisons}, Time: {kmp_time:.8f}s")
print("\nNaive Algorithm:")
print(f"Matches: {naive_matches}, Comparisons: {naive_comparisons}, Time: {naive_time:.8f}s")
