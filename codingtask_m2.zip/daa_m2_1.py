# permutations_from_scratch.py
# Generate all permutations of a list (no built-ins like itertools.permutations used)

def permutations(arr):
    result = []
    used = [False]*len(arr)
    current = []

    def backtrack():
        if len(current) == len(arr):
            result.append(current.copy())
            return
        for i in range(len(arr)):
            if used[i]:
                continue
            used[i] = True
            current.append(arr[i])
            backtrack()
            current.pop()
            used[i] = False

    backtrack()
    return result

if __name__ == "__main__":
    data = [1, 'a', 3.14]  # works for any data type
    perms = permutations(data)
    print(f"Permutations of {data}:")
    for p in perms:
        print(p)
    print("Total:", len(perms))
