# karatsuba.py
# Karatsuba algorithm for multiplication of two integers (recursive)

def karatsuba(x, y):
    # base case for small numbers
    if x < 10 or y < 10:
        return x * y
    # find the size of the numbers
    n = max(len(str(x)), len(str(y)))
    m = n // 2
    # split
    high_x = x // 10**m
    low_x  = x % 10**m
    high_y = y // 10**m
    low_y  = y % 10**m
    # three recursive steps
    z0 = karatsuba(low_x, low_y)
    z2 = karatsuba(high_x, high_y)
    z1 = karatsuba(low_x + high_x, low_y + high_y) - z2 - z0
    return (z2 * 10**(2*m)) + (z1 * 10**m) + z0

if __name__ == "__main__":
    a = int(input("Enter first large integer: ").strip())
    b = int(input("Enter second large integer: ").strip())
    print("Karatsuba product:", karatsuba(a, b))
    print("Verify (Python *):", a*b)
