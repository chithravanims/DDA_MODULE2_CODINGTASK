# combinations_from_scratch.py
# Generate all combinations (subsets) of a given size k from a list (no itertools)

def combinations(arr, k):
    result = []
    current = []

    def backtrack(start):
        if len(current) == k:
            result.append(current.copy())
            return
        for i in range(start, len(arr)):
            current.append(arr[i])
            backtrack(i+1)
            current.pop()

    backtrack(0)
    return result

if __name__ == "__main__":
    data = ['a', 'b', 'c', 4]
    k = 2
    combs = combinations(data, k)
    print(f"All {k}-combinations of {data}:")
    for c in combs:
        print(c)
    print("Total:", len(combs))
