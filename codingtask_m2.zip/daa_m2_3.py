# check_random_bit.py
import random

def int_to_binary(n):
    return bin(n)[2:]  # string without '0b'

if __name__ == "__main__":
    n = int(input("Enter a non-negative integer: "))
    b = int_to_binary(n)
    length = len(b)
    pos = random.randint(0, length-1)  # 0-based from leftmost bit
    # If you prefer position counted from right (LSB), adjust accordingly.
    bit_at_pos = b[pos]
    print(f"Integer: {n}")
    print(f"Binary (MSB->LSB): {b}")
    print(f"Random position (0-based from left): {pos}")
    print(f"Bit at position {pos} is: {bit_at_pos}")
    print("Is it 1?", bit_at_pos == '1')
