# tsp_bruteforce_5cities.py
# Brute-force TSP for 5 cities using all permutations.
import itertools

def tsp_bruteforce(dist_matrix):
    n = len(dist_matrix)
    cities = list(range(n))
    best_cost = float('inf')
    best_path = None
    # fix start city to 0 to avoid equivalent rotations
    for perm in itertools.permutations(cities[1:]):
        path = (0,) + perm + (0,)
        cost = 0
        valid = True
        for i in range(len(path)-1):
            a, b = path[i], path[i+1]
            cost += dist_matrix[a][b]
        if cost < best_cost:
            best_cost = cost
            best_path = path
    return best_cost, best_path

if __name__ == "__main__":
    # Example symmetric distance matrix for 5 cities (0..4)
    dist = [
        [0, 2, 9, 10, 7],
        [1, 0, 6, 4, 3],
        [15, 7, 0, 8, 9],
        [6, 3, 12, 0, 11],
        [10, 4, 8, 5, 0]
    ]
    cost, path = tsp_bruteforce(dist)
    print("Best route cost:", cost)
    print("Best route (city order):", path)
