# knapsack_bruteforce_binary.py
# 6 items, brute-force using binary masks

def knapsack_bruteforce(weights, values, capacity):
    n = len(weights)
    best_value = 0
    best_mask = 0
    for mask in range(1 << n):  # 0 .. 2^n -1
        total_w = 0
        total_v = 0
        for i in range(n):
            if mask & (1 << i):
                total_w += weights[i]
                total_v += values[i]
        if total_w <= capacity and total_v > best_value:
            best_value = total_v
            best_mask = mask
    items = [i for i in range(n) if best_mask & (1<<i)]
    return best_value, items

if __name__ == "__main__":
    weights = [3, 2, 4, 5, 1, 6]  # 6 items
    values  = [6, 4, 5, 7, 3, 9]
    capacity = 10
    best_val, chosen = knapsack_bruteforce(weights, values, capacity)
    print("Best value:", best_val)
    print("Chosen item indices (0-based):", chosen)
