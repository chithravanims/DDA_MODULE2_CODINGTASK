# knapsack_bruteforce_combinations.py
# Use combinations of sizes 0..n to brute-force knapsack

from itertools import combinations

def knapsack_using_combinations(weights, values, capacity):
    n = len(weights)
    best_value = 0
    best_set = None
    for r in range(n+1):
        for comb in combinations(range(n), r):
            total_w = sum(weights[i] for i in comb)
            total_v = sum(values[i] for i in comb)
            if total_w <= capacity and total_v > best_value:
                best_value = total_v
                best_set = comb
    return best_value, list(best_set) if best_set is not None else []

if __name__ == "__main__":
    weights = [3, 2, 4, 5, 1, 6]
    values  = [6, 4, 5, 7, 3, 9]
    capacity = 10
    best_val, chosen = knapsack_using_combinations(weights, values, capacity)
    print("Best value:", best_val)
    print("Chosen items:", chosen)
