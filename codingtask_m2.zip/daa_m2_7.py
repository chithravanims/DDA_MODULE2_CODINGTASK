# closest_pair_dac.py
# Divide and conquer closest pair algorithm (O(n log n))

import math
import random

def dist(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])

def brute_force(points):
    min_d = float('inf')
    n = len(points)
    pair = None
    for i in range(n):
        for j in range(i+1, n):
            d = dist(points[i], points[j])
            if d < min_d:
                min_d = d
                pair = (points[i], points[j])
    return min_d, pair

def strip_closest(strip, d):
    min_d = d
    pair = None
    strip.sort(key=lambda p: p[1])  # sort by y
    for i in range(len(strip)):
        j = i + 1
        while j < len(strip) and (strip[j][1] - strip[i][1]) < min_d:
            cur_d = dist(strip[i], strip[j])
            if cur_d < min_d:
                min_d = cur_d
                pair = (strip[i], strip[j])
            j += 1
    return min_d, pair

def closest_pair_rec(points_sorted_x):
    n = len(points_sorted_x)
    if n <= 3:
        return brute_force(points_sorted_x)
    mid = n // 2
    mid_x = points_sorted_x[mid][0]

    dl, pair_l = closest_pair_rec(points_sorted_x[:mid])
    dr, pair_r = closest_pair_rec(points_sorted_x[mid:])
    if dl < dr:
        d = dl
        pair = pair_l
    else:
        d = dr
        pair = pair_r

    strip = [p for p in points_sorted_x if abs(p[0] - mid_x) < d]
    ds, pair_s = strip_closest(strip, d)
    if ds < d:
        return ds, pair_s
    return d, pair

def closest_pair(points):
    points_sorted_x = sorted(points, key=lambda p: p[0])
    return closest_pair_rec(points_sorted_x)

if __name__ == "__main__":
    # Example random points
    pts = [(random.uniform(0,100), random.uniform(0,100)) for _ in range(20)]
    d, pair = closest_pair(pts)
    print("Closest distance:", d)
    print("Pair:", pair)
