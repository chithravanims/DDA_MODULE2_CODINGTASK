# matrix_multiply.py
# Multiply two matrices given by user input (validate dimensions)

def read_matrix(name):
    r = int(input(f"Enter number of rows for {name}: "))
    c = int(input(f"Enter number of columns for {name}: "))
    print(f"Enter {r} rows, each with {c} space-separated numbers:")
    mat = []
    for _ in range(r):
        row = list(map(int, input().split()))
        if len(row) != c:
            raise ValueError("Row length does not match columns.")
        mat.append(row)
    return mat

def multiply(A, B):
    r1, c1 = len(A), len(A[0])
    r2, c2 = len(B), len(B[0])
    if c1 != r2:
        raise ValueError("Incompatible dimensions for multiplication.")
    C = [[0]*c2 for _ in range(r1)]
    for i in range(r1):
        for j in range(c2):
            s = 0
            for k in range(c1):
                s += A[i][k] * B[k][j]
            C[i][j] = s
    return C

if __name__ == "__main__":
    try:
        A = read_matrix("Matrix A")
        B = read_matrix("Matrix B")
        C = multiply(A, B)
        print("Resultant Matrix:")
        for row in C:
            print(' '.join(map(str, row)))
    except Exception as e:
        print("Error:", e)
