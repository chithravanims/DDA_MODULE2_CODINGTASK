# otp_bruteforce_simulation.py
# IMPORTANT: This is a SAFE SIMULATION only.
# I will NOT provide code to attack real systems.
# This demonstrates brute-force concept against a local mock function.

import time

def mock_verify_otp(otp_str):
    # This simulates the correct OTP stored locally for testing.
    # In real systems you must never attempt brute force.
    return otp_str == "0427"

def brute_force_4digit_mock():
    start = time.time()
    attempts = 0
    found = None
    for i in range(10000):  # 0000..9999
        otp = f"{i:04d}"
        attempts += 1
        if mock_verify_otp(otp):
            found = otp
            break
    end = time.time()
    print("Simulation complete.")
    if found:
        print("Found OTP (in simulation):", found)
    else:
        print("OTP not found in simulation.")
    print("Attempts:", attempts, "Time(s):", end - start)

if __name__ == "__main__":
    print("This script simulates brute-forcing a locally defined OTP checker for educational purposes only.")
    brute_force_4digit_mock()
